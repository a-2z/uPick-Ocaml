(* Global constants to be shared in the whole directory *)

let user_key = failwith "unimplemented"