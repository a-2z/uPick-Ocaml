# 3110Project (Add Name)

A mobile app used to decide what restaurant to eat at among a group of friends based on location and user preferences. 
Each member of the group ranks their top choices and the algorithm takes the preferences to subsequently display the preferred option.

Andrew Zeng, Andrew Osorio, Zachary Tegtmeier, Reetu Parikh

Once we have more info to document:
https://guides.github.com/features/wikis/
